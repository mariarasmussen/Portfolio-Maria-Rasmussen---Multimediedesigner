"use strict";

// hide all pages - SIMONE, SOFIE, MARIA
function hideAllPages() {
  let pages = document.querySelectorAll(".page");
  for (let page of pages) {
    page.style.display = "none";
  }
}

// show page or tab - MARIA
function showPage(pageId) {
  hideAllPages();
  document.querySelector(`#${pageId}`).style.display = "block";
  console.log(pageId);
  if (pageId === "startGuide1" || pageId === "startGuide2" || pageId === "startGuide3" || pageId === "startGuide4" || pageId === "startGuide5" || pageId === "loginRegistrer" || pageId === "opret" || pageId === "slutGuide" || pageId === "login" || pageId === "slutGuide") {
    showTabbar(false);
    showHeader(false);
  } else {
    showTabbar(true);
    showHeader(true);
  }
  setActiveTab(pageId);
}

// sets active tabbar/ menu item - SOFIE, SIMONE, MARIA
function setActiveTab(pageId) {
  let pages = document.querySelectorAll(".tabbar a");
  for (let page of pages) {
    if (`#${pageId}` === page.getAttribute("href")) {
      page.classList.add("active");
    } else {
      page.classList.remove("active");
    }
  }
}

// sets active tabbar/ menu item - SOFIE, SIMONE, MARIA
function setActiveTab(pageId) {
  let pages = document.querySelectorAll(".header a");
  for (let page of pages) {
    if (`#${pageId}` === page.getAttribute("href")) {
      page.classList.add("active");
    } else {
      page.classList.remove("active");
    }
  }
}


// SOFIE
function closeMenu() {
  document.querySelector("#mobileicon").checked = false;
}

// SOFIE
function goBack() {
  window.history.back();
}

// MARIA 
function showHeader(show) {
  let tabbar = document.querySelector('#header');
  if (show) {
    tabbar.classList.remove("hide");
  } else {
    tabbar.classList.add('hide');
  }
}

//MARIA 
function showTabbar(show) {
  let tabbar = document.querySelector('.tabbar');
  if (show) {
    tabbar.classList.remove("hide");
  } else {
    tabbar.classList.add('hide');
  }
}

// navigate to a new view/page by changing href - SOFIE
function navigateTo(pageId) {
  location.href = `#${pageId}`;
}

// set default page or given page by the hash url
// function is called 'onhashchange' - SOFIE, SIMONE, MARIA
function pageChange() {
  let page = "startGuide1";
  if (location.hash) {
    page = location.hash.slice(1);
  }
  showPage(page);
}

pageChange(); // called by default when the app is loaded for the first time