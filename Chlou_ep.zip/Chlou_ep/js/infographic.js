// When the user clicks on <div>, open the popup
function eyelashPopup() {
    var popup = document.getElementById("eyelash-popup");
    popup.classList.toggle("show");
}

function eyebrowPopup() {
    var popup = document.getElementById("eyebrow-popup");
    popup.classList.toggle("show");
}
